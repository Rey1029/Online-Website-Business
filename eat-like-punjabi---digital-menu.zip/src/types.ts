export interface MenuItem {
  name: string;
  price: string | number;
  description?: string;
}

export interface MenuSection {
  category: string;
  items: MenuItem[];
}

export const MENU_DATA: MenuSection[] = [
  {
    category: "Special Dishes",
    items: [
      { name: "Sarson Da Saag (Makki Di Roti)", price: 450 },
      { name: "Chole Chawal", price: 290 },
      { name: "Chole Bhature", price: 290 },
      { name: "Rajma Chawal", price: 290 },
      { name: "Kadhi Chawal", price: 280 }
    ]
  },
  {
    category: "Thali",
    items: [
      { name: "Veg Thali", price: 250 },
      { name: "Non Veg Thali", price: 350 }
    ]
  },
  {
    category: "Veg Main Course",
    items: [
      { name: "Butter Paneer", price: 310 },
      { name: "Paneer Bhurji", price: 290 },
      { name: "Paneer Tikka Masala", price: 300 },
      { name: "Paneer Lababdar", price: 300 },
      { name: "Veg Kadai", price: 240 },
      { name: "Paneer Kadai", price: 260 },
      { name: "Dal Panjratni", price: 400 },
      { name: "Mix Veg", price: 300 },
      { name: "Veg Patiala", price: 300 },
      { name: "Jeera Aloo", price: 250 },
      { name: "Punjabi Kadhi Pakoda", price: 310 },
      { name: "Punjabi Rajma", price: 310 },
      { name: "Palak Paneer", price: 320 },
      { name: "Dal Tadka / Fry", price: 250 },
      { name: "Dal Makhani", price: 400 },
      { name: "Mushroom Mutter", price: 310 },
      { name: "Bhind Do Pyaza", price: 280 },
      { name: "Veg Kofta", price: 300 }
    ]
  },
  {
    category: "Non-Veg Main Course",
    items: [
      { name: "Chicken Masala Curry", price: 440 },
      { name: "Chicken Handi", price: 370 },
      { name: "Chicken Patiala", price: 350 }
    ]
  },
  {
    category: "Veg Starters",
    items: [
      { name: "Veg Pakoda", price: 150 },
      { name: "Paneer Pakoda", price: 250 },
      { name: "Mix Pakoda", price: 220 },
      { name: "Paneer Tikka", price: 280 },
      { name: "Paneer Malai Tikka", price: 310 },
      { name: "Paneer Pahadi Tikka", price: 310 },
      { name: "Mushroom Tandoori", price: 280 },
      { name: "Veg Seekh Kebab", price: 250 },
      { name: "French Fries", price: 150 },
      { name: "Hara Bhara Kebab", price: 240 },
      { name: "Veg Starters Platter", price: 420 }
    ]
  },
  {
    category: "Non-Veg Starters",
    items: [
      { name: "Chicken Tandoori (Full)", price: 600 },
      { name: "Chicken Tandoori (Half)", price: 350 },
      { name: "Chicken Tikka", price: 310 },
      { name: "Chicken Malai Tikka", price: 340 }
    ]
  },
  {
    category: "Breakfast Special",
    items: [
      { name: "Chole Bhature", price: 210 },
      { name: "Aloo Puri", price: 200 },
      { name: "Egg Bhurji", price: 150 },
      { name: "Masala Omelette", price: 110 },
      { name: "Bread Omelette", price: 130 },
      { name: "Butter Toast (4 pcs)", price: 80 },
      { name: "Veg Sandwich", price: 150 },
      { name: "Veg Grill Sandwich", price: 180 },
      { name: "Masala Omelette Sandwich", price: 150 }
    ]
  },
  {
    category: "Breads",
    items: [
      { name: "Tandoori Roti (Butter)", price: "20 / 25" },
      { name: "Naan (Butter)", price: "40 / 50" },
      { name: "Laccha Paratha", price: 50 },
      { name: "Aloo Paratha", price: 120 },
      { name: "Gobi Paratha", price: 120 },
      { name: "Paneer Paratha", price: 150 },
      { name: "Garlic Naan (Butter)", price: "80 / 100" },
      { name: "Plain Paratha", price: 50 },
      { name: "Missi Paratha", price: 120 },
      { name: "Mix Paratha", price: 160 },
      { name: "Cheese Garlic Naan", price: 150 },
      { name: "Chapati (Butter)", price: "20 / 30" },
      { name: "Rumali Roti (Butter)", price: "60 / 70" }
    ]
  },
  {
    category: "Rice",
    items: [
      { name: "Steam Rice", price: "120/190" },
      { name: "Jeera Rice", price: 170 },
      { name: "Curd Rice", price: 230 },
      { name: "Veg Biryani", price: 210 },
      { name: "Chicken Biryani", price: 350 },
      { name: "Egg Biryani", price: 290 },
      { name: "Tawa Pulao", price: 220 },
      { name: "Veg Pulao", price: 220 }
    ]
  },
  {
    category: "Chinese",
    items: [
      { name: "Veg Noodles", price: 200 },
      { name: "Chicken Noodles", price: 250 },
      { name: "Chicken Chilli (Dry/Gravy)", price: "150 / 320" }
    ]
  },
  {
    category: "Soups",
    items: [
      { name: "Tomato Soup", price: 100 },
      { name: "Chicken Soup", price: 160 },
      { name: "Veg Manchow Soup", price: 110 },
      { name: "Chicken Manchow Soup", price: 140 }
    ]
  },
  {
    category: "Juice & Shakes",
    items: [
      { name: "Watermelon Juice", price: 150 },
      { name: "Pomegranate Juice", price: 180 },
      { name: "Orange Juice", price: 150 },
      { name: "Mosambi Juice", price: 150 },
      { name: "Mango Shake", price: 210 },
      { name: "Banana Shake", price: 190 },
      { name: "Chocolate Shake", price: 210 },
      { name: "Cold Coffee", price: 210 }
    ]
  },
  {
    category: "Beverages",
    items: [
      { name: "Sweet Lassi", price: 120 },
      { name: "Chaas", price: 70 },
      { name: "Masala Tea", price: 120 },
      { name: "Coffee", price: 120 },
      { name: "Black Coffee", price: 70 },
      { name: "Fresh Lime Soda", price: 120 },
      { name: "Cold Drinks", price: "MRP" },
      { name: "Nimbu Pani", price: 90 },
      { name: "Water Bottle (1L/500ml)", price: "30 / 15" }
    ]
  }
];
