/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useMemo, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Utensils, 
  ChevronRight, 
  QrCode, 
  X, 
  Search, 
  MapPin, 
  Phone,
  Info,
  Menu as MenuIcon,
  MessageCircle,
  LayoutGrid
} from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';
import { MENU_DATA, type MenuItem, type MenuSection } from './types';

export default function App() {
  const [activeCategory, setActiveCategory] = useState<string>(MENU_DATA[0].category);
  const [searchQuery, setSearchQuery] = useState('');
  const [showQR, setShowQR] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const filteredMenu = useMemo(() => {
    if (!searchQuery) return MENU_DATA;
    return MENU_DATA.map(section => ({
      ...section,
      items: section.items.filter(item => 
        item.name.toLowerCase().includes(searchQuery.toLowerCase())
      )
    })).filter(section => section.items.length > 0);
  }, [searchQuery]);

  const currentAppUrl = typeof window !== 'undefined' ? window.location.href : '';

  useEffect(() => {
    const handleScroll = () => {
      const sections = MENU_DATA.map(s => document.getElementById(`section-${s.category}`));
      const scrollPosition = window.scrollY + 300;

      for (let i = sections.length - 1; i >= 0; i--) {
        const section = sections[i];
        if (section && section.offsetTop <= scrollPosition) {
          setActiveCategory(MENU_DATA[i].category);
          break;
        }
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToCategory = (category: string) => {
    setActiveCategory(category);
    const el = document.getElementById(`section-${category}`);
    if (el) {
      const offset = 100;
      const bodyRect = document.body.getBoundingClientRect().top;
      const elementRect = el.getBoundingClientRect().top;
      const elementPosition = elementRect - bodyRect;
      const offsetPosition = elementPosition - offset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
    setIsMobileMenuOpen(false);
  };

  return (
    <div className="min-h-screen bg-brand-black selection:bg-brand-orange/30">
      {/* Header */}
      <nav className="fixed top-0 left-0 w-full z-40 bg-brand-black/80 backdrop-blur-md px-6 py-6 border-b border-white/5">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h1 className="font-serif text-xl font-bold text-brand-gold tracking-tight uppercase">
              Eat Like Punjabi
            </h1>
          </div>
          
          <div className="hidden md:flex items-center gap-10">
            {['MENU', 'OUR STORY', 'EVENTS'].map(link => (
              <a key={link} href="#" className="text-sm font-medium text-brand-muted hover:text-white transition-colors">{link}</a>
            ))}
            <button className="bg-brand-orange text-white px-8 py-2.5 rounded-full font-bold text-sm hover:brightness-110 shadow-lg shadow-brand-orange/20 transition-all">
              Reserve
            </button>
          </div>

          <button 
            className="md:hidden text-white"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? <X size={24} /> : <MenuIcon size={24} />}
          </button>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-40 pb-20 px-6 text-center">
        <div className="max-w-4xl mx-auto space-y-6">
          <p className="text-brand-gold font-bold tracking-[0.4em] text-[10px] uppercase opacity-80">
            Digital Menu
          </p>
          <h2 className="font-serif text-5xl md:text-8xl font-bold tracking-tight leading-tight">
            <span className="text-white">REAL PUNJABI </span>
            <span className="text-brand-orange italic font-normal">SOUL FOOD</span>
          </h2>
          
          <div className="max-w-xl mx-auto relative pt-10">
            <Search className="absolute left-6 top-[72px] text-brand-muted" size={20} />
            <input 
              type="text"
              placeholder="Search for your favorite dish..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-brand-surface/40 border border-white/10 rounded-full py-5 pl-16 pr-6 text-white text-sm outline-none focus:border-brand-orange/50 transition-all"
            />
          </div>
        </div>
      </section>

      {/* Main Content Area */}
      <div className="max-w-7xl mx-auto px-6 pb-40 flex flex-col md:flex-row gap-12">
        {/* Sidebar Navigation */}
        <aside className="hidden lg:block w-72 shrink-0 sticky top-32 h-fit space-y-2">
          {MENU_DATA.map((section) => (
            <button
              key={section.category}
              onClick={() => scrollToCategory(section.category)}
              className={`
                w-full group flex items-center justify-between p-4 rounded-xl text-left transition-all
                ${activeCategory === section.category 
                  ? 'bg-brand-orange text-white shadow-xl shadow-brand-orange/20' 
                  : 'text-brand-muted hover:bg-white/5 hover:text-white'}
              `}
            >
              <div className="space-y-0.5">
                {section.category === "Special Dishes" && (
                  <span className="text-[8px] font-bold uppercase tracking-widest block opacity-60">Signature</span>
                )}
                <span className="font-bold text-sm uppercase tracking-tight">{section.category}</span>
              </div>
              <ChevronRight size={16} className={`${activeCategory === section.category ? 'opacity-100' : 'opacity-0 group-hover:opacity-40'} transition-opacity`} />
            </button>
          ))}
        </aside>

        {/* Menu Grid */}
        <div className="flex-grow space-y-32">
          {filteredMenu.map((section) => (
            <section 
              key={section.category} 
              id={`section-${section.category}`}
              className="scroll-mt-40 bg-brand-surface/30 rounded-[40px] p-8 md:p-14 border border-white/5"
            >
              <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-20">
                <div>
                  <h2 className="font-serif text-3xl md:text-5xl font-bold text-brand-gold uppercase">
                    {section.category}
                  </h2>
                  <p className="text-[10px] text-brand-muted font-bold uppercase tracking-[0.2em] mt-3">
                    Authentic Flavours From The North
                  </p>
                </div>
                <span className="text-[10px] font-bold text-brand-muted uppercase tracking-widest bg-white/5 px-4 py-2 rounded-full h-fit self-start md:self-auto">
                  {section.items.length} Items
                </span>
              </div>
              
              <div className="grid md:grid-cols-2 gap-x-12 gap-y-12">
                {section.items.map((item, idx) => (
                  <motion.div
                    key={`${section.category}-${item.name}`}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    className="group"
                  >
                    <div className="flex items-end justify-between mb-2">
                      <h3 className="font-serif text-xl md:text-2xl font-semibold text-white/90 group-hover:text-brand-orange transition-colors">
                        {item.name}
                      </h3>
                      <div className="dotted-line" />
                      <span className="menu-item-price shrink-0 min-w-fit">
                        {typeof item.price === 'number' ? `₹${item.price}` : item.price}
                      </span>
                    </div>
                    <div className="flex items-center gap-3">
                      <p className="text-[9px] md:text-[10px] text-brand-muted font-bold uppercase tracking-widest">
                        Hand-Crafted • Single Portion
                      </p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </section>
          ))}
        </div>
      </div>

      {/* Floating Action Buttons */}
      <div className="fixed bottom-10 right-10 flex flex-col gap-4 z-50">
        <button 
          onClick={() => setShowQR(true)}
          className="bg-brand-surface border border-white/10 p-4 rounded-full text-brand-gold shadow-2xl hover:bg-brand-gold hover:text-white transition-all transform hover:-translate-y-1"
        >
          <LayoutGrid size={24} />
        </button>
        <button 
          className="bg-green-500 p-4 rounded-full text-white shadow-2xl hover:brightness-110 transition-all transform hover:-translate-y-1"
        >
          <MessageCircle size={24} />
        </button>
      </div>

      {/* QR Code Modal */}
      <AnimatePresence>
        {showQR && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-brand-black/95 backdrop-blur-md flex items-center justify-center p-6"
            onClick={() => setShowQR(false)}
          >
            <motion.div 
              initial={{ scale: 0.9, y: 40 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 40 }}
              onClick={e => e.stopPropagation()}
              className="bg-brand-surface border border-white/10 p-10 rounded-[40px] w-full max-w-md shadow-2xl text-center space-y-8"
            >
              <div className="space-y-2">
                <Utensils className="mx-auto text-brand-orange mb-4" size={48} />
                <h3 className="font-serif text-3xl font-bold text-white">Digital Menu</h3>
                <p className="text-sm text-brand-muted">Scan to access the full menu on your device</p>
              </div>

              <div className="bg-white p-6 rounded-[32px] inline-block shadow-inner">
                <QRCodeSVG 
                  id="menu-qrcode"
                  value={currentAppUrl}
                  size={240}
                  level="H"
                  includeMargin={true}
                />
              </div>

              <button 
                onClick={() => setShowQR(false)}
                className="w-full bg-brand-orange text-white py-5 rounded-full font-bold text-lg hover:brightness-110 transition-all"
              >
                Close Stand
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Mobile Drawer (Categories) */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div 
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            className="fixed inset-0 z-50 bg-brand-black lg:hidden"
          >
            <div className="p-6 h-full flex flex-col">
              <div className="flex items-center justify-between mb-10">
                <h2 className="font-serif text-2xl font-bold text-brand-gold">Menu</h2>
                <button onClick={() => setIsMobileMenuOpen(false)} className="text-white">
                  <X size={32} />
                </button>
              </div>
              <div className="flex-grow overflow-y-auto space-y-1">
                {MENU_DATA.map((section) => (
                  <button
                    key={section.category}
                    onClick={() => scrollToCategory(section.category)}
                    className="w-full text-left py-4 px-2 border-b border-white/5 text-xl font-bold uppercase tracking-tight text-white hover:text-brand-orange transition-colors"
                  >
                    {section.category}
                  </button>
                ))}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
