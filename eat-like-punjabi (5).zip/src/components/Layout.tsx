import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Menu as MenuIcon, 
  X, 
  Phone, 
  Instagram, 
  MapPin, 
  ChevronUp,
  MessageCircle,
  LayoutDashboard
} from 'lucide-react';

export const Navbar = () => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 80);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Menu', href: '/menu' },
    { name: 'Our Story', href: '/#story' },
    { name: 'Events', href: '/#occasions' },
  ];

  return (
    <nav className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${
      scrolled ? 'bg-charcoal/95 backdrop-blur-md border-b border-white/5 py-4 shadow-lg' : 'bg-transparent py-8'
    }`}>
      <div className="max-w-7xl mx-auto px-6 md:px-12 flex justify-between items-center">
        <Link to="/" className="font-display text-2xl text-gold uppercase tracking-tight">Eat Like Punjabi</Link>
        
        <div className="hidden md:flex items-center gap-12">
          {navLinks.map(link => (
             link.href.startsWith('/#') ? (
               <a key={link.name} href={link.href} className="text-muted hover:text-gold transition-colors font-medium text-sm tracking-widest uppercase">
                 {link.name}
               </a>
             ) : (
               <Link key={link.name} to={link.href} className="text-muted hover:text-gold transition-colors font-medium text-sm tracking-widest uppercase">
                 {link.name}
               </Link>
             )
          ))}
          <a href="/#reserve" className="bg-flame hover:bg-flame-dark text-white px-8 py-3 rounded-full font-bold text-sm tracking-widest transition-all hover:scale-105 active:scale-95 shadow-xl">Reserve</a>
        </div>

        <button className="md:hidden text-cream" onClick={() => setMobileMenuOpen(true)}>
          <MenuIcon />
        </button>
      </div>

      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div 
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            className="fixed inset-0 bg-charcoal z-[60] flex flex-col p-8"
          >
            <div className="flex justify-end mb-12">
              <button onClick={() => setMobileMenuOpen(false)}><X className="w-8 h-8" /></button>
            </div>
            <div className="flex flex-col gap-8 text-3xl font-display">
              {navLinks.map(link => (
                link.href.startsWith('/#') ? (
                  <a key={link.name} href={link.href} onClick={() => setMobileMenuOpen(false)} className="text-cream">{link.name}</a>
                ) : (
                  <Link key={link.name} to={link.href} onClick={() => setMobileMenuOpen(false)} className="text-cream">{link.name}</Link>
                )
              ))}
              <a href="/#reserve" onClick={() => setMobileMenuOpen(false)} className="text-flame">Reserve</a>
              <Link to="/admin" onClick={() => setMobileMenuOpen(false)} className="text-gold/50 text-sm mt-8">Admin Portal</Link>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

export const Footer = () => {
  return (
    <footer className="bg-charcoal pt-24 pb-12 px-12 border-t border-white/5">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-12 mb-24">
        <div className="col-span-1 md:col-span-2">
          <h2 className="text-3xl text-gold font-display mb-6 tracking-tight">Eat Like Punjabi</h2>
          <p className="text-muted max-w-sm mb-8 italic">Honest flavours, soulful music, and a warm Punjabi heart. Re-discovering the magic of North Indian home-cooking in the heart of Andheri.</p>
          <div className="flex gap-4">
            <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="w-10 h-10 rounded-full bg-card-dark flex items-center justify-center text-muted hover:text-gold transition-colors border border-white/5"><Instagram className="w-5 h-5" /></a>
            <a href="tel:+917400452761" className="w-10 h-10 rounded-full bg-card-dark flex items-center justify-center text-muted hover:text-gold transition-colors border border-white/5"><Phone className="w-5 h-5" /></a>
          </div>
        </div>
        <div>
          <h4 className="text-gold font-bold mb-6 uppercase tracking-widest text-sm">Quick Links</h4>
          <ul className="space-y-4 text-muted">
            <li><Link to="/menu" className="hover:text-gold transition-colors">Digital Menu</Link></li>
            <li><a href="/#reserve" className="hover:text-gold transition-colors">Reservations</a></li>
            <li><a href="/#story" className="hover:text-gold transition-colors">Our Story</a></li>
            <li><Link to="/admin" className="text-gold/40 hover:text-gold transition-colors text-[10px]">Admin Login</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="text-gold font-bold mb-6 uppercase tracking-widest text-sm">Find Us</h4>
          <p className="text-muted mb-4">Bungalow No 190, Mhada Rd, behind Versova,<br/>Four Bungalows, Andheri West,<br/>Mumbai, Maharashtra 400053</p>
          <a href="tel:+917400452761" className="text-gold mb-4 font-mono block hover:underline">+91 7400452761</a>
          <p className="text-muted flex items-center gap-2"><Clock className="w-4 h-4 text-flame" /> 12 PM - 11:30 PM (Daily)</p>
        </div>
      </div>
      <div className="max-w-7xl mx-auto pt-12 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-6">
        <p className="text-muted text-xs tracking-widest uppercase">© 2026 Eat Like Punjabi. Created with Punjabi Soul.</p>
        <button onClick={() => window.scrollTo({top: 0, behavior: 'smooth'})} className="flex items-center gap-2 text-gold text-xs font-bold tracking-widest uppercase group">
          Back to Top <ChevronUp className="w-4 h-4 group-hover:-translate-y-1 transition-transform" />
        </button>
      </div>
    </footer>
  );
};

const Clock = ({ className }: { className?: string }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <circle cx="12" cy="12" r="10" />
    <polyline points="12 6 12 12 16 14" />
  </svg>
);

export const Layout = ({ children }: { children: React.ReactNode }) => {
  return (
    <div className="bg-charcoal text-cream font-sans min-h-screen relative">
      <Navbar />
      {children}
      <Footer />
      
      {/* Floating Actions */}
      <div className="fixed bottom-8 right-8 z-[100] flex flex-col gap-4">
        {/* Admin Portal Button */}
        <Link 
          to="/admin" 
          className="bg-card-dark text-gold p-4 rounded-full shadow-2xl hover:scale-110 active:scale-95 transition-all group border border-gold/20 flex items-center justify-center"
          aria-label="Admin Portal"
        >
          <LayoutDashboard className="w-6 h-6" />
          <span className="absolute right-full mr-4 bg-white text-charcoal px-3 py-1 rounded-lg text-xs font-bold whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity shadow-xl pointer-events-none">Admin Portal</span>
        </Link>

        {/* Floating WhatsApp */}
        <a 
          href="https://wa.me/917400452761" 
          target="_blank" 
          rel="noopener noreferrer"
          className="bg-[#25D366] text-white p-4 rounded-full shadow-2xl hover:scale-110 active:scale-95 transition-all group flex items-center justify-center"
          aria-label="Contact us on WhatsApp"
        >
          <MessageCircle className="w-6 h-6" />
          <span className="absolute right-full mr-4 bg-white text-charcoal px-3 py-1 rounded-lg text-xs font-bold whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity shadow-xl pointer-events-none">Chat with us</span>
        </a>
      </div>
    </div>
  );
};
