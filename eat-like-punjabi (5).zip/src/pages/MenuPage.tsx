import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, ChevronRight, Search } from 'lucide-react';
import { collection, query, onSnapshot, orderBy } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { MENU_CATEGORIES, MENU_ITEMS } from '../data/menu';
import { RevealText } from '../components/SectionFade';

const MenuPage = () => {
  const [activeTab, setActiveTab] = useState('specials');
  const [searchQuery, setSearchQuery] = useState('');
  const [dynamicItems, setDynamicItems] = useState<any[]>([]);
  const [hiddenItems, setHiddenItems] = useState<Set<string>>(new Set());

  useEffect(() => {
    window.scrollTo(0, 0);

    const q = query(collection(db, 'menu_items'), orderBy('createdAt', 'asc'));
    const unsub = onSnapshot(q, (snapshot) => {
      setDynamicItems(snapshot.docs.map(doc => doc.data()));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'menu_items');
    });

    const unsubHidden = onSnapshot(collection(db, 'hidden_menu_items'), (snapshot) => {
      setHiddenItems(new Set(snapshot.docs.map(doc => doc.id)));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'hidden_menu_items');
    });

    return () => {
      unsub();
      unsubHidden();
    };
  }, []);

  const filteredItems = (catId: string) => {
    const staticItems = (MENU_ITEMS[catId] || []).filter(item => !hiddenItems.has(`${catId}:${item.name}`));
    const dynamicItemsForCat = dynamicItems.filter(item => item.category === catId);
    const items = [...staticItems, ...dynamicItemsForCat];
    
    if (!searchQuery) return items;
    return items.filter(item => 
      item.name.toLowerCase().includes(searchQuery.toLowerCase())
    );
  };

  return (
    <div className="pt-32 pb-24 px-6 md:px-12 bg-charcoal min-h-screen">
      <div className="max-w-7xl mx-auto">
        <header className="text-center mb-16 px-4">
          <RevealText delay={0.2} className="mb-4">
            <p className="text-gold uppercase tracking-[0.4em] text-xs font-bold">Digital Menu</p>
          </RevealText>
          <RevealText delay={0.4}>
            <h1 className="text-4xl md:text-7xl font-display text-cream uppercase">
              Real Punjabi <span className="text-flame">Soul Food</span>
            </h1>
          </RevealText>
          
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.8 }}
            className="relative max-w-md mx-auto mt-12 mb-12"
          >
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted" />
            <input 
              type="text"
              placeholder="Search for your favorite dish..."
              className="w-full bg-card-dark border border-white/10 rounded-full py-3 px-12 focus:outline-none focus:border-gold transition-all text-sm"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </motion.div>
        </header>

        {/* Categories Sidebar/Tabs */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          <div className="lg:col-span-3 flex lg:flex-col overflow-x-auto lg:overflow-visible pb-4 lg:pb-0 gap-2 no-scrollbar sticky top-32 z-10">
            {MENU_CATEGORIES.map(cat => (
              <button
                key={cat.id}
                onClick={() => {
                  setActiveTab(cat.id);
                  setSearchQuery('');
                  if (window.innerWidth < 1024) {
                     const el = document.getElementById('menu-content');
                     el?.scrollIntoView({ behavior: 'smooth', block: 'start' });
                  }
                }}
                className={`flex-shrink-0 px-6 py-3 rounded-full lg:rounded-xl transition-all duration-300 border-2 lg:border lg:text-left whitespace-nowrap font-medium ${
                  activeTab === cat.id 
                  ? 'bg-flame border-flame text-cream shadow-xl shadow-flame/10' 
                  : 'bg-card-dark/50 border-white/5 text-muted hover:border-gold/30 hover:text-gold'
                }`}
              >
                <div className="flex items-center justify-between">
                   <div className="flex flex-col">
                     {cat.promo && <span className="text-[8px] opacity-70 uppercase tracking-widest leading-none mb-1">{cat.promo}</span>}
                     <span className="text-sm md:text-base">{cat.name}</span>
                   </div>
                   <ChevronRight className={`hidden lg:block w-4 h-4 transition-transform ${activeTab === cat.id ? 'translate-x-1 opacity-100' : 'opacity-0'}`} />
                </div>
              </button>
            ))}
          </div>

          {/* Menu Content */}
          <div id="menu-content" className="lg:col-span-9 bg-card-dark/30 rounded-[2rem] border border-white/5 p-8 md:p-12 min-h-[600px] backdrop-blur-sm shadow-2xl">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeTab + searchQuery}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-2"
              >
                <div className="col-span-full border-b border-white/10 pb-6 mb-8 flex justify-between items-end">
                   <div>
                     <h2 className="text-3xl text-gold font-display uppercase tracking-tight">{MENU_CATEGORIES.find(c => c.id === activeTab)?.name}</h2>
                     <p className="text-xs text-muted mt-2 uppercase tracking-[0.2em]">Authentic Flavours From The North</p>
                   </div>
                   <span className="text-xs font-mono text-muted/40 font-bold">{filteredItems(activeTab).length} Items</span>
                </div>

                {filteredItems(activeTab).length > 0 ? (
                  filteredItems(activeTab).map((item, idx) => (
                    <motion.div 
                      key={item.name}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: idx * 0.02 }}
                      className="py-5 border-b border-white/5 flex items-center justify-between group cursor-default"
                    >
                      <div className="flex-1 pr-6">
                        <div className="flex items-baseline gap-2">
                          <span className="font-display text-xl text-cream group-hover:text-gold transition-colors duration-300 capitalize">{item.name.toLowerCase()}</span>
                          <div className="flex-1 border-b border-dotted border-white/20 group-hover:border-gold/40 transition-colors duration-300"></div>
                          <span className="text-gold font-bold text-lg tabular-nums">₹{item.price}</span>
                        </div>
                        <p className="text-[10px] text-muted uppercase tracking-[0.3em] mt-2 opacity-40 font-bold italic">Hand-crafted • Single Portion</p>
                      </div>
                    </motion.div>
                  ))
                ) : (
                  <div className="col-span-full py-24 text-center">
                    <p className="text-muted italic text-lg">No dishes found matching your search. Try another query.</p>
                  </div>
                )}
              </motion.div>
            </AnimatePresence>
            
            <div className="mt-24 pt-12 border-t border-white/10 text-center">
               <p className="text-muted text-sm italic mb-8 font-serif">"Pricing is inclusive of all taxes. Seasonal availability may apply to certain dishes."</p>
               <div className="w-16 h-[1px] bg-gold/30 mx-auto"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MenuPage;
