import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  X, 
  LayoutDashboard, 
  LogOut, 
  AlertCircle,
  CheckCircle,
  XCircle,
  Phone,
  Calendar,
  Clock,
  Users,
  Eye,
  EyeOff,
  ChevronDown,
  MessageCircle
} from 'lucide-react';
import { 
  collection, 
  query, 
  orderBy, 
  onSnapshot,
  doc,
  updateDoc,
  deleteDoc,
  addDoc,
  setDoc,
  serverTimestamp
} from 'firebase/firestore';
import { onAuthStateChanged, signOut, User } from 'firebase/auth';
import { db, auth, signInWithGoogle, signInAsGuest, handleFirestoreError, OperationType } from '../lib/firebase';
import { MENU_CATEGORIES, MENU_ITEMS } from '../data/menu';

const Admin = () => {
  const [user, setUser] = useState<User | null>(null);
  const [showLogin, setShowLogin] = useState(true);
  const [activeTab, setActiveTab] = useState<'reservations' | 'menu'>('reservations');
  
  // Reservation state
  const [loginId, setLoginId] = useState('');
  const [password, setPassword] = useState('');
  const [loginError, setLoginError] = useState('');
  const [reservations, setReservations] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [processingId, setProcessingId] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);
  
  // Menu state
  const [menuItems, setMenuItems] = useState<any[]>([]);
  const [hiddenItems, setHiddenItems] = useState<Set<string>>(new Set());
  const [newDish, setNewDish] = useState({ name: '', price: '', category: MENU_CATEGORIES[0].id });
  const [menuLoading, setMenuLoading] = useState(false);
  const [showStaticMenu, setShowStaticMenu] = useState(false);

  const navigate = useNavigate();

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (u) => {
      setUser(u);
      if (u) {
        setShowLogin(false);
        fetchReservations();
        fetchMenuItems();
        fetchHiddenItems();
      } else {
        setShowLogin(true);
      }
    });
    return () => unsub();
  }, []);

  const fetchReservations = () => {
    setLoading(true);
    const q = query(collection(db, 'reservations'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));
      setReservations(data);
      setLoading(false);
    }, (err) => {
      handleFirestoreError(err, OperationType.LIST, 'reservations');
      setLoading(false);
      setErrorMsg("Database access restricted. Please log in with an authorized account.");
    });
    return unsubscribe;
  };

  const fetchMenuItems = () => {
    setMenuLoading(true);
    const q = query(collection(db, 'menu_items'), orderBy('createdAt', 'asc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));
      setMenuItems(data);
      setMenuLoading(false);
    }, (err) => {
      handleFirestoreError(err, OperationType.LIST, 'menu_items');
    });
    return unsubscribe;
  };

  const fetchHiddenItems = () => {
    const unsubscribe = onSnapshot(collection(db, 'hidden_menu_items'), (snapshot) => {
      const hidden = new Set(snapshot.docs.map(doc => doc.id));
      setHiddenItems(hidden);
    }, (err) => {
      handleFirestoreError(err, OperationType.LIST, 'hidden_menu_items');
    });
    return unsubscribe;
  };

  const toggleStaticItemVisibility = async (category: string, name: string) => {
    const dishKey = `${category}:${name}`;
    try {
      if (hiddenItems.has(dishKey)) {
        await deleteDoc(doc(db, 'hidden_menu_items', dishKey));
      } else {
        await setDoc(doc(db, 'hidden_menu_items', dishKey), { dishKey });
      }
    } catch (err: any) {
      handleFirestoreError(err, OperationType.WRITE, 'hidden_menu_items');
      setErrorMsg(`Failed to update visibility: ${err.message}`);
    }
  };

  const handleAddDish = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDish.name || !newDish.price) return;
    
    setMenuLoading(true);
    try {
      await addDoc(collection(db, 'menu_items'), {
        ...newDish,
        createdAt: serverTimestamp()
      });
      setNewDish({ ...newDish, name: '', price: '' });
    } catch (err: any) {
      handleFirestoreError(err, OperationType.CREATE, 'menu_items');
      setErrorMsg(`Failed to add dish: ${err.message}`);
    } finally {
      setMenuLoading(false);
    }
  };

  const deleteMenuItem = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'menu_items', id));
    } catch (err: any) {
      handleFirestoreError(err, OperationType.DELETE, 'menu_items');
      setErrorMsg(`Failed to delete dish: ${err.message}`);
    }
  };

  const handleManualLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');
    if (loginId.trim() === 'admin' && password === '1234') {
      try {
        await signInAsGuest();
      } catch (err: any) {
        setLoginError(`Authentication failed: ${err.message}. Please ensure Anonymous Auth is enabled in Firebase.`);
        console.error("Guest login error:", err);
      }
    } else {
      setLoginError('Invalid Administrator ID or Password.');
    }
  };

  const handleGoogleLogin = async () => {
    setLoginError('');
    try {
      await signInWithGoogle();
    } catch (err: any) {
      if (err.code === 'auth/popup-blocked') {
        setLoginError('Popup blocked! Please allow popups for this site or open the app in a new tab.');
      } else {
        setLoginError(`Google sign-in failed: ${err.message}`);
      }
      console.error("Google login error:", err);
    }
  };

  const handleLogout = () => {
    signOut(auth);
    navigate('/');
  };

  const updateStatus = async (id: string, status: string) => {
    setProcessingId(id);
    try {
      await updateDoc(doc(db, 'reservations', id), { status });
    } catch (err: any) {
      handleFirestoreError(err, OperationType.UPDATE, 'reservations');
      setErrorMsg(`Failed to update: ${err.message}`);
    } finally {
      setProcessingId(null);
    }
  };

  const deleteReservation = async (id: string) => {
    setProcessingId(id);
    try {
      await deleteDoc(doc(db, 'reservations', id));
      setConfirmDelete(null);
    } catch (err: any) {
      handleFirestoreError(err, OperationType.DELETE, 'reservations');
      setErrorMsg(`Failed to delete: ${err.message}`);
    } finally {
      setProcessingId(null);
    }
  };

  const sendWhatsAppConfirmation = (res: any) => {
    const message = `Namaste ${res.name}, Your reservation at Eat Like Punjabi for ${res.date} at ${res.time} for ${res.guests} guests has been confirmed. See you soon! 

📍 Bungalow No 190, Mhada Rd, behind Versova, Four Bungalows, Andheri West, Mumbai, Maharashtra 400053.
📞 +91 7400452761`;
    
    // Clean phone number: remove non-digits. Ensure it starts with 91 if not present.
    let cleanPhone = res.phone.replace(/\D/g, '');
    if (cleanPhone.length === 10) cleanPhone = '91' + cleanPhone;
    
    const url = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank');
  };

  if (showLogin) {
    return (
      <div className="min-h-screen pt-32 pb-12 flex items-center justify-center p-6 bg-charcoal">
        <div className="w-full max-w-md bg-card-dark p-8 md:p-12 rounded-[2.5rem] border border-gold/20 shadow-2xl relative">
          <div className="text-center mb-10">
            <h2 className="text-3xl font-display text-gold mb-2">Owner Login</h2>
            <p className="text-muted text-xs uppercase tracking-widest">Access the Vault</p>
          </div>

          <form onSubmit={handleManualLogin} className="space-y-8">
            <div className="border-b border-gold/20 pb-2">
              <label className="text-[9px] uppercase tracking-widest text-muted block mb-1">Owner ID</label>
              <input type="text" required className="w-full bg-transparent py-1 text-sm outline-none" value={loginId} onChange={e => setLoginId(e.target.value)} placeholder="admin" />
            </div>
            <div className="border-b border-gold/20 pb-2">
              <label className="text-[9px] uppercase tracking-widest text-muted block mb-1">Password</label>
              <input type="password" required className="w-full bg-transparent py-1 text-sm outline-none" value={password} onChange={e => setPassword(e.target.value)} placeholder="••••" />
            </div>
            {loginError && <p className="text-red-500 text-[10px] text-center font-bold">{loginError}</p>}
            <button className="w-full bg-flame py-4 rounded text-sm font-bold uppercase tracking-widest hover:brightness-110 transition-all">Login</button>
          </form>

          <div className="mt-8 pt-8 border-t border-white/5 text-center">
            <button onClick={handleGoogleLogin} className="text-xs text-gold font-bold hover:underline">Sign in with Google</button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-charcoal pt-32 px-6 md:px-12 pb-24">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-12 gap-6">
          <div>
            <h1 className="text-4xl font-display text-gold flex items-center gap-4">
              <LayoutDashboard /> Admin Dashboard
            </h1>
            <p className="text-muted mt-2">Authenticated as: <span className="text-cream font-bold">{user?.email || "Manager"}</span></p>
          </div>
          <button onClick={handleLogout} className="flex items-center gap-2 text-muted hover:text-flame transition-colors font-bold uppercase tracking-widest text-xs">
            <LogOut className="w-4 h-4" /> Logout
          </button>
        </div>

        {errorMsg && (
          <div className="mb-8 p-4 bg-red-500/10 border border-red-500/20 rounded-2xl flex items-center gap-3 text-red-500 text-sm">
            <AlertCircle className="w-5 h-5 flex-shrink-0" />
            <span className="flex-1">{errorMsg}</span>
            <button onClick={() => setErrorMsg(null)} className="text-[10px] font-bold">DISMISS</button>
          </div>
        )}

        {/* Tab Switcher */}
        <div className="flex gap-4 mb-8">
          <button 
            onClick={() => setActiveTab('reservations')}
            className={`px-6 py-2 rounded-full text-xs font-bold uppercase tracking-widest transition-all ${activeTab === 'reservations' ? 'bg-gold text-charcoal' : 'text-muted border border-white/10 hover:border-gold/30'}`}
          >
            Reservations
          </button>
          <button 
            onClick={() => setActiveTab('menu')}
            className={`px-6 py-2 rounded-full text-xs font-bold uppercase tracking-widest transition-all ${activeTab === 'menu' ? 'bg-gold text-charcoal' : 'text-muted border border-white/10 hover:border-gold/30'}`}
          >
            Manage Menu
          </button>
        </div>

        {activeTab === 'reservations' ? (
          <div className="grid grid-cols-1 gap-6">
            {loading ? (
              <p className="text-center py-24 opacity-50">Loading...</p>
            ) : reservations.length === 0 ? (
              <div className="text-center py-24 bg-card-dark rounded-3xl border border-white/5"><p className="text-muted">No reservations.</p></div>
            ) : (
              reservations.map(res => (
                <div key={res.id} className="bg-card-dark p-6 md:p-8 rounded-3xl border border-white/5 hover:border-gold/20 transition-all flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
                  <div className="flex-1">
                    <div className="flex items-center gap-4 mb-3">
                      <span className="text-xl font-bold text-cream">{res.name}</span>
                      <span className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest ${
                        res.status === 'confirmed' ? 'bg-green-500/20 text-green-500' :
                        res.status === 'cancelled' ? 'bg-red-500/20 text-red-500' : 'bg-gold/20 text-gold'
                      }`}>{res.status}</span>
                    </div>
                    <div className="flex flex-wrap gap-x-6 gap-y-2 text-sm text-muted italic">
                      <span className="flex items-center gap-2"><Phone className="w-3 h-3" /> {res.phone}</span>
                      <span className="flex items-center gap-2"><Calendar className="w-3 h-3" /> {res.date}</span>
                      <span className="flex items-center gap-2"><Clock className="w-3 h-3" /> {res.time}</span>
                      <span className="flex items-center gap-2"><Users className="w-3 h-3" /> {res.guests} Guests</span>
                    </div>
                    {res.specialRequests && <p className="mt-4 text-xs italic bg-black/20 p-3 rounded-lg border border-white/5 text-muted/80">"{res.specialRequests}"</p>}
                  </div>
                  
                  <div className="flex flex-wrap gap-3">
                    {res.status === 'confirmed' && (
                      <button 
                        onClick={() => sendWhatsAppConfirmation(res)} 
                        className="bg-[#25D366] text-white px-5 py-2 rounded-lg text-xs font-bold hover:brightness-110 transition-all flex items-center gap-2"
                      >
                        <MessageCircle className="w-3 h-3" /> WhatsApp Conf.
                      </button>
                    )}
                    {res.status === 'pending' && (
                      <button disabled={!!processingId} onClick={() => updateStatus(res.id, 'confirmed')} className="bg-green-500 text-white px-5 py-2 rounded-lg text-xs font-bold hover:bg-green-600 transition-all">Confirm</button>
                    )}
                    {res.status !== 'cancelled' && (
                      <button disabled={!!processingId} onClick={() => updateStatus(res.id, 'cancelled')} className="bg-white/10 text-cream px-5 py-2 rounded-lg text-xs font-bold hover:bg-red-500 transition-all">Cancel</button>
                    )}
                    
                    {confirmDelete === res.id ? (
                      <div className="flex gap-2">
                        <button onClick={() => deleteReservation(res.id)} className="bg-red-600 text-white px-4 py-2 rounded-lg text-xs font-bold">Confirm</button>
                        <button onClick={() => setConfirmDelete(null)} className="text-muted text-xs">Back</button>
                      </div>
                    ) : (
                      <button onClick={() => setConfirmDelete(res.id)} className="bg-transparent text-muted/50 hover:text-red-500 transition-colors text-xs font-bold">Delete</button>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        ) : (
          <div className="space-y-12">
            {/* Add Dish Form */}
            <div className="bg-card-dark p-8 md:p-12 rounded-[2.5rem] border border-gold/20 shadow-2xl">
              <h2 className="text-2xl font-display text-gold mb-8 italic">Add New Dish to Menu</h2>
              <form onSubmit={handleAddDish} className="grid grid-cols-1 md:grid-cols-4 gap-8 items-end">
                <div className="border-b border-white/10 pb-2">
                  <label className="text-[9px] uppercase tracking-widest text-muted block mb-1">Category</label>
                  <select 
                    className="w-full bg-transparent text-sm outline-none text-cream"
                    value={newDish.category}
                    onChange={e => setNewDish({...newDish, category: e.target.value})}
                  >
                    {MENU_CATEGORIES.map(cat => (
                      <option key={cat.id} value={cat.id} className="bg-charcoal">{cat.name}</option>
                    ))}
                  </select>
                </div>
                <div className="border-b border-white/10 pb-2 md:col-span-2">
                  <label className="text-[9px] uppercase tracking-widest text-muted block mb-1">Dish Name</label>
                  <input 
                    type="text" 
                    required 
                    placeholder="e.g. Special Butter Chicken"
                    className="w-full bg-transparent py-1 text-sm outline-none text-cream"
                    value={newDish.name}
                    onChange={e => setNewDish({...newDish, name: e.target.value})}
                  />
                </div>
                <div className="border-b border-white/10 pb-2">
                  <label className="text-[9px] uppercase tracking-widest text-muted block mb-1">Price (₹)</label>
                  <input 
                    type="text" 
                    required 
                    placeholder="e.g. 450"
                    className="w-full bg-transparent py-1 text-sm outline-none text-cream"
                    value={newDish.price}
                    onChange={e => setNewDish({...newDish, price: e.target.value})}
                  />
                </div>
                <div className="md:col-span-4 flex justify-end">
                  <button 
                    disabled={menuLoading}
                    className="bg-flame text-white px-12 py-4 rounded-xl text-xs font-bold uppercase tracking-widest hover:brightness-110 transition-all disabled:opacity-50"
                  >
                    Add to Digital Menu
                  </button>
                </div>
              </form>
            </div>

            {/* Current Dynamic Items List */}
            <div className="space-y-6">
              <div className="flex justify-between items-center bg-card-dark p-6 rounded-3xl border border-white/5">
                <h3 className="text-xl font-display text-muted italic">Static Menu Visibility</h3>
                <button 
                  onClick={() => setShowStaticMenu(!showStaticMenu)}
                  className="text-gold flex items-center gap-2 text-xs font-bold uppercase tracking-widest"
                >
                  {showStaticMenu ? 'Hide List' : 'Show List'}
                  <ChevronDown className={`w-4 h-4 transition-transform ${showStaticMenu ? 'rotate-180' : ''}`} />
                </button>
              </div>

              {showStaticMenu && (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                  {MENU_CATEGORIES.map(cat => (
                    <div key={cat.id} className="space-y-4">
                      <h4 className="text-gold font-display text-sm border-b border-gold/10 pb-2">{cat.name}</h4>
                      <div className="space-y-2 max-h-64 overflow-y-auto pr-2 custom-scrollbar">
                        {(MENU_ITEMS[cat.id] || []).map((item, idx) => {
                          const dishKey = `${cat.id}:${item.name}`;
                          const isHidden = hiddenItems.has(dishKey);
                          return (
                            <div key={idx} className="flex justify-between items-center group p-2 rounded-lg hover:bg-white/5 transition-colors">
                              <span className={`text-xs ${isHidden ? 'text-muted line-through opacity-50' : 'text-cream'}`}>{item.name}</span>
                              <button 
                                onClick={() => toggleStaticItemVisibility(cat.id, item.name)}
                                className={`p-1.5 rounded-full transition-all ${isHidden ? 'text-red-500 bg-red-500/10' : 'text-green-500 hover:bg-green-500/10'}`}
                                title={isHidden ? 'Hidden (Click to show)' : 'Visible (Click to hide)'}
                              >
                                {isHidden ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                              </button>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  ))}
                </div>
              )}

              <h3 className="text-xl font-display text-muted italic pt-8">Dynamic Menu Items (Added by Admin)</h3>
              {menuItems.length === 0 ? (
                <p className="text-muted italic opacity-50">No dynamic items yet.</p>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {menuItems.map(item => {
                    const categoryName = MENU_CATEGORIES.find(c => c.id === item.category)?.name || item.category;
                    return (
                      <div key={item.id} className="bg-card-dark p-6 rounded-3xl border border-white/5 flex justify-between items-center group hover:border-gold/20 transition-all">
                        <div>
                          <p className="text-[9px] uppercase tracking-widest text-gold mb-1">{categoryName}</p>
                          <h4 className="text-cream font-bold">{item.name}</h4>
                          <p className="text-muted text-sm italic">₹{item.price}</p>
                        </div>
                        <button 
                          onClick={() => deleteMenuItem(item.id)}
                          className="text-muted/30 hover:text-red-500 transition-colors"
                        >
                          <XCircle className="w-5 h-5" />
                        </button>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Admin;
