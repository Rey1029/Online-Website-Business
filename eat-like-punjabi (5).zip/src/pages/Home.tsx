import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Link } from 'react-router-dom';
import { 
  Star, 
  Music, 
  Home as HomeIcon, 
  Camera, 
  Users, 
  Phone, 
  MapPin, 
  ChevronUp,
  CheckCircle,
  Clock
} from 'lucide-react';
import { 
  collection, 
  addDoc, 
  serverTimestamp
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { SectionFade, RevealText } from '../components/SectionFade';

const BicycleIcon = ({ className = "" }: { className?: string }) => (
  <svg viewBox="0 0 100 60" className={className} stroke="currentColor" fill="none" strokeWidth="1.5">
    <circle cx="20" cy="40" r="15" />
    <circle cx="80" cy="40" r="15" />
    <path d="M20 40 L40 10 L80 10 L80 40 M40 10 L30 25 M80 10 L90 5 M50 10 L50 40 M20 40 L80 40" />
    <path d="M48 10 L52 10 M50 10 L55 5" />
  </svg>
);

const Hero = () => {
  return (
    <section className="relative h-screen w-full flex items-center justify-center overflow-hidden bg-charcoal">
      <div className="absolute inset-0 z-0" style={{ background: 'radial-gradient(circle at 50% 30%, #3d1a00 0%, #0d0600 100%)' }}></div>
      <div className="absolute inset-0 opacity-10 pointer-events-none overflow-hidden">
        <motion.div 
          animate={{ x: [0, 500, 0], y: [0, 200, 0] }}
          transition={{ duration: 25, repeat: Infinity, ease: "linear" }}
          className="absolute -top-1/2 -left-1/2 w-full h-full bg-gold/10 blur-[150px] rounded-full"
        />
      </div>

      <div className="relative z-10 text-center px-8 max-w-5xl">
        <RevealText delay={0.2} className="mb-6">
          <p className="text-gold uppercase text-[10px] font-bold tracking-[0.3em]">Andheri · Mumbai</p>
        </RevealText>
        
        <RevealText delay={0.4} className="mb-8">
          <h1 className="text-6xl md:text-8xl text-cream font-black leading-[1.1]">
            Mumbai's Most <br/>Underrated <br/><span className="text-flame">Punjabi Secret</span>
          </h1>
        </RevealText>

        <motion.p 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1, duration: 1 }}
          className="text-lg md:text-xl text-muted mb-12 max-w-xl mx-auto leading-relaxed"
        >
          Homely flavours. Soulful cooking. A hidden gem the regulars don't advertise.
        </motion.p>

        <motion.div 
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 1.2 }}
          className="flex flex-col sm:flex-row gap-6 justify-center items-center"
        >
          <a href="#reserve" className="bg-flame text-white px-12 py-4 rounded-full font-bold uppercase tracking-widest text-sm hover:scale-105 transition-all shadow-2xl">Reserve a Table</a>
          <Link to="/menu" className="border-2 border-gold/40 text-gold hover:border-gold hover:bg-gold/5 px-12 py-4 rounded-full font-bold uppercase tracking-widest text-sm transition-all">Explore Menu</Link>
        </motion.div>
      </div>

      <motion.div 
        initial={{ opacity: 0, x: 100 }}
        animate={{ opacity: 0.4, x: 0 }}
        transition={{ delay: 1.5, duration: 1.5 }}
        className="absolute bottom-[-10%] right-[-5%] w-64 md:w-96 text-gold pointer-events-none"
      >
        <BicycleIcon />
      </motion.div>
    </section>
  );
};

const TrustBar = () => {
  return (
    <SectionFade className="bg-card-dark py-12 overflow-hidden border-y border-white/5">
      <div className="max-w-7xl mx-auto px-8 grid grid-cols-1 md:grid-cols-3 gap-12 items-center text-center md:text-left mb-8">
        <div className="flex items-center justify-center md:justify-start gap-4">
          <div className="flex flex-col items-center md:items-start">
            <div className="flex text-gold text-xs mb-1 group"><Star className="fill-gold w-3 h-3" /><Star className="fill-gold w-3 h-3" /><Star className="fill-gold w-3 h-3" /><Star className="fill-gold w-3 h-3" /><Star className="fill-gold w-3 h-3 opacity-30" /></div>
            <p className="text-[10px] text-muted uppercase font-bold tracking-tighter">Google Rated</p>
          </div>
          <div className="h-8 w-[1px] bg-white/10 hidden md:block"></div>
          <p className="text-sm font-medium">Loved across Mumbai</p>
        </div>
        <div className="flex flex-col items-center gap-1">
          <p className="font-bold text-sm uppercase tracking-widest text-gold mb-1">Authentic</p>
          <p className="text-xs text-muted">Real recipes, no shortcuts</p>
        </div>
        <div className="text-sm text-cream font-medium italic opacity-80">
          "There is magic in this place" — <span className="opacity-60 not-italic uppercase text-[10px] tracking-tighter">The regulars know.</span>
        </div>
      </div>
    </SectionFade>
  );
};

const Story = () => (
  <SectionFade id="story" className="py-24 px-12">
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center max-w-7xl mx-auto">
      <motion.div 
        initial={{ scale: 0.9, opacity: 0 }}
        whileInView={{ scale: 1, opacity: 1 }}
        transition={{ duration: 1 }}
        className="relative aspect-square bg-card-dark rounded-[2rem] overflow-hidden group border border-white/5"
      >
        <div className="absolute inset-0 flex items-center justify-center">
          <BicycleIcon className="w-1/2 text-gold/20 group-hover:scale-110 transition-transform duration-700" />
        </div>
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1544148103-0773bf10d330?auto=format&fit=crop&q=80&w=1000')] bg-cover bg-center mix-blend-overlay"></div>
      </motion.div>

      <div className="space-y-6">
        <RevealText delay={0.2}><p className="text-flame uppercase tracking-[3px] text-sm font-bold">Hidden in Andheri</p></RevealText>
        <RevealText delay={0.4}><h2 className="text-4xl md:text-5xl lg:text-6xl text-cream font-display">Famous in Every Heart It's Touched</h2></RevealText>
        <motion.p 
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ delay: 0.6, duration: 1 }}
          className="text-muted leading-relaxed text-lg"
        >
          Eat Like Punjabi lets the food do the talking. Tucked away in Andheri, it's the kind of place that turns first-timers into regulars. The ambiance is quirky, warm, and unmistakably Punjabi.
        </motion.p>
        <motion.div 
          initial={{ x: -20, opacity: 0 }}
          whileInView={{ x: 0, opacity: 1 }}
          transition={{ delay: 0.8 }}
          className="border-l-2 border-flame pl-6 py-2"
        >
          <p className="text-gold italic text-xl">"Every time I visit Mumbai, this is non-negotiable."</p>
        </motion.div>
        <div className="pt-4">
          <Link to="/menu" className="inline-flex items-center gap-2 text-gold font-bold uppercase tracking-widest text-xs border-b border-gold/30 pb-2 hover:border-gold transition-all">Explore the digital menu</Link>
        </div>
      </div>
    </div>
  </SectionFade>
);

const Reservation = () => {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    date: '',
    time: '7:00 PM',
    guests: '4',
    specialRequests: ''
  });
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [errorStatus, setErrorStatus] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setErrorStatus(null);
    setSuccess(false);

    try {
      await addDoc(collection(db, 'reservations'), {
        ...formData,
        guests: parseInt(formData.guests) || 1,
        status: 'pending',
        createdAt: serverTimestamp()
      });
      setSuccess(true);
      setFormData({ name: '', phone: '', date: '', time: '7:00 PM', guests: '4', specialRequests: '' });
    } catch (err: any) {
      console.error("Booking error details:", err);
      try {
        handleFirestoreError(err, OperationType.CREATE, 'reservations');
      } catch (e) {
        // Log original error if it wasn't a firestore permission error
      }
      setErrorStatus("Failed to book. Please try calling us at +91 07400452761.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <SectionFade id="reserve" className="py-24 px-12">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-24 max-w-7xl mx-auto">
        <div>
          <RevealText><h2 className="text-5xl md:text-7xl mb-6 font-display">Book Your Table</h2></RevealText>
          <motion.p initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} transition={{ delay: 0.3 }} className="text-muted text-xl mb-12">Reservations are recommended for peak hours and groups.</motion.p>
          <div className="space-y-8 text-cream">
            <motion.div initial={{ x: -20, opacity: 0 }} whileInView={{ x: 0, opacity: 1 }} transition={{ delay: 0.4 }} className="flex gap-4 items-center">
              <div className="w-12 h-12 rounded-full bg-card-dark border border-white/5 flex items-center justify-center text-gold"><MapPin /></div>
              <div><p className="font-bold">Andheri, Mumbai</p></div>
            </motion.div>
            <motion.div initial={{ x: -20, opacity: 0 }} whileInView={{ x: 0, opacity: 1 }} transition={{ delay: 0.5 }} className="flex gap-4 items-center">
              <div className="w-12 h-12 rounded-full bg-card-dark border border-white/5 flex items-center justify-center text-gold"><Phone /></div>
              <div><p className="font-bold">+91 07400452761</p></div>
            </motion.div>
          </div>
        </div>

        <motion.div 
          initial={{ y: 40, opacity: 0 }}
          whileInView={{ y: 0, opacity: 1 }}
          viewport={{ once: true }}
          className="bg-card-dark p-8 md:p-12 rounded-[2rem] border border-white/5 shadow-2xl relative overflow-hidden"
        >
          {success ? (
            <div className="text-center py-12">
              <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-6" />
              <h3 className="text-2xl font-bold mb-2">Request Sent!</h3>
              <p className="text-muted">We'll confirm your reservation shortly.</p>
              <button onClick={() => setSuccess(false)} className="mt-8 text-gold border-b border-gold uppercase text-xs font-bold tracking-widest">Book another</button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-8">
              {errorStatus && (
                <div className="bg-red-500/10 border border-red-500/20 text-red-400 p-4 rounded-xl text-sm italic">
                  {errorStatus}
                </div>
              )}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="border-b border-white/10 pb-2">
                  <label className="text-[10px] uppercase tracking-widest text-muted block mb-1">Name</label>
                  <input type="text" required placeholder="Full Name" className="bg-transparent w-full outline-none py-1 text-cream" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} />
                </div>
                <div className="border-b border-white/10 pb-2">
                  <label className="text-[10px] uppercase tracking-widest text-muted block mb-1">Phone</label>
                  <input type="tel" required placeholder="+91..." className="bg-transparent w-full outline-none py-1 text-cream" value={formData.phone} onChange={e => setFormData({...formData, phone: e.target.value})} />
                </div>
              </div>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-8">
                <div className="border-b border-white/10 pb-2">
                  <label className="text-[10px] uppercase tracking-widest text-muted block mb-1">Date</label>
                  <input type="date" required className="bg-transparent w-full outline-none py-1 text-cream" value={formData.date} onChange={e => setFormData({...formData, date: e.target.value})} />
                </div>
                <div className="border-b border-white/10 pb-2">
                  <label className="text-[10px] uppercase tracking-widest text-muted block mb-1">Time</label>
                  <select className="bg-transparent w-full outline-none py-1 text-cream" value={formData.time} onChange={e => setFormData({...formData, time: e.target.value})}>
                    {['12:00 PM', '1:00 PM', '7:00 PM', '8:00 PM', '9:00 PM'].map(t => <option key={t} value={t} className="bg-charcoal">{t}</option>)}
                  </select>
                </div>
                <div className="border-b border-white/10 pb-2">
                  <label className="text-[10px] uppercase tracking-widest text-muted block mb-1">Guests</label>
                  <input type="number" required min="1" max="50" className="bg-transparent w-full outline-none py-1 text-cream" value={formData.guests} onChange={e => setFormData({...formData, guests: e.target.value})} />
                </div>
              </div>
              <button disabled={loading} className="w-full bg-flame hover:bg-flame-dark text-white py-4 rounded-xl font-bold uppercase tracking-widest transition-all shadow-xl shadow-flame/20 disabled:opacity-50">
                {loading ? 'Sending Request...' : 'Request Reservation'}
              </button>
            </form>
          )}
        </motion.div>
      </div>
    </SectionFade>
  );
};

const Vibe = () => {
  const cards = [
    { icon: <Music />, title: "Live Music & Atmosphere", desc: "A vibe that hits different the moment you walk in" },
    { icon: <HomeIcon />, title: "Punjab in Mumbai", desc: "AC dining upstairs styled to feel like home — real Punjabi home" },
    { icon: <Camera />, title: "The Famous Cycle", desc: "Our little icon. Photograph it before your food arrives — or after." }
  ];

  return (
    <SectionFade className="py-12 px-12">
      <div className="py-24 px-12 bg-gradient-to-br from-charcoal to-card-dark max-w-7xl mx-auto rounded-[3rem] border border-white/5 overflow-hidden">
        <RevealText className="text-center mb-16"><h2 className="text-4xl md:text-6xl text-cream font-display">Eat With Peace. Eat With Music.</h2></RevealText>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {cards.map((card, i) => (
            <motion.div 
              key={card.title} 
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.2, duration: 0.8 }}
              className="p-8 rounded-3xl bg-card-dark/50 border border-gold/10 hover:border-gold/30 group transition-all duration-500 hover:-translate-y-2"
            >
              <div className="text-gold mb-6 group-hover:scale-110 transition-transform duration-500">{card.icon}</div>
              <h3 className="text-2xl text-cream mb-4 font-display">{card.title}</h3>
              <p className="text-muted italic text-sm">{card.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </SectionFade>
  );
};

const Testimonials = () => {
  const reviews = [
    { text: "Every trip to Mumbai, this is the first table I book.", name: "Manori", loc: "Mumbai" },
    { text: "Tikkas genuinely soft and succulent. Five stars.", name: "Ollie", loc: "Mumbai" },
    { text: "The go-to for authentic Punjabi. Epic joint.", name: "Sanjay", loc: "Mumbai" }
  ];

  return (
    <SectionFade className="py-24 px-12 bg-charcoal overflow-hidden max-w-7xl mx-auto">
      <RevealText className="text-center mb-16"><h2 className="text-4xl md:text-6xl font-display uppercase tracking-tight">The Regulars Know</h2></RevealText>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {reviews.map((rev, i) => (
          <motion.div 
            key={i} 
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            transition={{ delay: i * 0.1 }}
            className="bg-card-dark p-8 rounded-3xl border border-white/5 hover:border-gold/20 transition-all"
          >
            <div className="text-4xl text-flame font-serif mb-4">"</div>
            <p className="text-cream text-lg mb-8 italic leading-relaxed">{rev.text}</p>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gold font-bold text-sm tracking-widest uppercase">{rev.name}</p>
              </div>
              <div className="flex text-gold text-[8px]">
                {[...Array(5)].map((_, i) => <Star key={i} className="fill-gold w-3 h-3" />)}
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </SectionFade>
  );
};

const Occasions = () => (
  <SectionFade id="occasions" className="py-24 px-12">
    <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-7xl mx-auto">
      {['Anniversaries', 'Birthdays', 'Corporate Feasts'].map((title, i) => (
        <motion.div 
          key={title} 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ delay: i * 0.1 }}
          className="bg-card-dark p-8 rounded-3xl border border-white/5 hover:border-gold/30 transition-all text-center"
        >
          <div className="text-gold mb-6 flex justify-center"><Users className="w-10 h-10" /></div>
          <h3 className="text-xl font-display text-cream mb-4">{title}</h3>
          <p className="text-muted text-sm italic">Set the table for your special moments with authentic Punjabi hospitality.</p>
        </motion.div>
      ))}
    </div>
  </SectionFade>
);

const Home = () => {
  return (
    <main>
      <Hero />
      <TrustBar />
      <Story />
      <Vibe />
      <Occasions />
      <Testimonials />
      <Reservation />
    </main>
  );
};

export default Home;
